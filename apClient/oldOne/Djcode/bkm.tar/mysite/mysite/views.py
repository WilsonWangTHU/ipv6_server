from django.shortcuts import render,render_to_response
from django.template.loader import get_template
from django.template import Context
from django.http import HttpResponse, HttpResponseRedirect
from mysite.tunnel_function import *

def login(request):
    
    login_flag=iflogin()
    if login_flag==1:
        return render_to_response('jump.html',{'jump_kind':1,'error':2,'next':'/'})
    return render_to_response('login.html')

def login_submit(request):
    login_flag=iflogin()
    if login_flag==1:
        return render_to_response('jump.html',{'jump_kind':1,'error':2,'next':'/'})
        
    error = userlogin(request)
    next_page='/login'
    html_page='jump.html'
    if error==1:
        first_config()
        html_page='first_login.html'
         
    return render_to_response(html_page,{'jump_kind':1,'error':error,'next':next_page})

def info(request):
    error = iflogin()
    if error==0:
        return render_to_response('jump.html',{'jump_kind':0,'next':'/login'})
    if error!=1:
        return render_to_response('jump.html',{'jump_kind':-1,'next':'/login'})
    error=iftunnel()
    return render_to_response('info.html',{'tunnel_type':error})

def ifconfig(response):
    response=HttpResponse()
    response['Contene-Type']="text/javascript"
    error = iftong()
    response.write(error)
    return response

def logout(request):
    error = quit_login()
    return render_to_response('jump.html',{'jump_kind':4,'next':'/login','error':error})

def choose_tunnel(request):
    error = iflogin()
    if error==0:
        return render_to_response('jump.html',{'jump_kind':0,'next':'/login'})  
    error = iftunnel()
    t = request.POST.get('type','')
    tunnel_type = int(t)
    if error != 0:
        return render_to_response('jump.html',{'jump_kind':2,'next':'/','error':3})
    error=-1
    if tunnel_type==1:
        error = tunnel_con1()
    if tunnel_type == 2:
        error = tunnel_con2()
    if tunnel_type == 3:
        error = tunnel_con()
    return render_to_response('jump.html',{'jump_kind':2,'next':'/','error':error})

def delete_tunnel(request):
    error = del_tunnel()
    return render_to_response('jump.html',{'jump_kind':3,'next':'/','error':error})
    

