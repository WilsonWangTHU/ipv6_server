import subprocess
import hashlib

def md5(t_str):
    m = hashlib.md5()
    m.update(t_str)
    return m.hexdigest()

def write_file(filename,string):
    output=open(filename,'w')
    output.write(string)
    output.close()

def read_file(filename):
    innput=open(filename,'r')
    all_text = innput.read()
    innput.close()
    return all_text

def send_message(cmd):
    p = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (t_out,err)=p.communicate()
    out = t_out.split('\n')
    t = out[0]
    return t_out 

def ping_test():
    cmd = "sudo ping6 -c 1 -w 1 ipv6.google.com"
    flag=0
    i=0
    while(i<3):
        t_out = send_message(cmd)
        out = t_out.split('\n')
        nn = out[0]
        if len(nn)>=3:
            n4 = out[4]
            out1 = n4.split(',')
            if(len(out1)<2):
                continue
            out2 = out1[1]
            out3 = out2[1]
            t = len(out[1])
            if out3 != '0':
                return 1
        i+=1
    return 0

