from function import *
from user_tunnel_info import *

dns_file='/etc/resolv.conf'

def return_ipv6_addr():
    ipv6_addr = read_config('TunnelInfo','ipv6_addr')
    ipv6_addr_netmask = read_config('TunnelInfo','ipv6_addr_netmask')
    ipv6_addr_prefix = ipv6_addr[:-1]+'/'+ipv6_addr_netmask
    return (ipv6_addr_prefix,ipv6_addr)

def return_ipv6_ivi_addr():
    ivi_addr = read_config('TunnelInfo','ivi_addr')
    ivi_addr_netmask = read_config('TunnelInfo','ivi_addr_netmask')
    ivi_addr_prefix = ivi_addr[:-6]+':/'+ivi_addr_netmask
    return (ivi_addr_prefix,ivi_addr)

def return_dns_server():
    t=read_file(dns_file)
    dns_info = t.split('\n')
    dns_addr = []
    for i in dns_info:
        if len(i)>0:
            t_addr = i.split(' ')[1]
            dns_addr.append(t_addr)
    return dns_addr

def return_ipv4_global_addr():
    return read_config('TunnelInfo','client_ipv4')

def return_server_address():
    ipv6_addr = read_config('TunnelInfo','ipv6_addr')
    ivi_addr = read_config('TunnelInfo','ivi_addr')
    ipv6_server_addr="http://["+ipv6_addr+"]:80"
    ipv6_server_ivi="http://["+ivi_addr+"]:80"
    return (ipv6_server_addr,ipv6_server_ivi)

    
    
