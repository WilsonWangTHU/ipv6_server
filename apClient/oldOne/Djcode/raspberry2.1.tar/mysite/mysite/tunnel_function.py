#!/usr/bin/python
import os
from sys import path
path.append(r"/project/Djcode/mysite/script")
from function import *
from communicate_with_server import *
from user_tunnel_info import *
from tunnel_local_manage import *

def iflogin():
    result = read_userinfo()
    error = result[0]
    return error

def iftunnel():
    result = read_tunnelinfo()
    error = result[0]
    return error

def quit_login():
    ti = read_tunnelinfo()
    set_first_conf('0')
    tunnel_type = ti[0]
    if tunnel_type==0:
        reset_userinfo()
        os.system("sudo /project/Djcode/mysite/script/logout_change_file") 
        return 1

    ui = read_userinfo()
    username = ui[1]
    password = ui[2]
    if tunnel_type==1: 
        delete_tunnel_A()
        reset_userinfo()
        os.system("sudo /project/Djcode/mysite/script/logout_change_file") 
        return 1

    if tunnel_type==2:
        delete_tunnel_C()
        reset_userinfo()
        os.system("sudo /project/Djcode/mysite/script/logout_change_file") 
        return 1
    return 0
        
def iftong():
    flag = read_first_conf()
    if flag==1:
        return 1
    else:
        return 0        
def first_config():
    os.system("sudo /project/Djcode/mysite/script/network_config.shell &")

def userlogin(resquest):
    t_username = resquest.POST.get('username','')
    t_password = resquest.POST.get('password','')
    pd = md5(t_password)
    result = write_userinfo(str(t_username),pd)
    return result

def tunnel_con1():
    user_info = read_userinfo()
    if user_info[0]==0:
        return -1
    tunnel_info = iftunnel()
    if tunnel_info!=0:
        return -1 
    username = str(user_info[1])
    password = user_info[2]
    write_tunnel_info_A(username,password)
    create_tunnel_A()
    error = ping_test()
    if error==1:
        return 1
    delete_tunnel_A()
    return 0

def tunnel_con2():
    user_info = read_userinfo()
    if user_info[0]==0:
        return -1
    tunnel_info = iftunnel()
    if tunnel_info!=0:
        return -1 
    username = str(user_info[1])
    password = user_info[2]
    write_tunnel_info_C(username,password)
    create_tunnel_C()
    error = ping_test()
    if error==1:
        return 2
    delete_tunnel_C()
    return 0

def tunnel_con3():
    user_info = read_userinfo()
    if user_info[0]==0:
        return -1
    tunnel_info = iftunnel()
    if tunnel_info!=0:
        return -1 
    username = str(user_info[1])
    password = user_info[2]
    write_tunnel_info_A(username,password)
    create_tunnel_A()
    error = ping_test()
    if error==1:
        return 1
    delete_tunnel_A()
    write_tunnel_info_C(username,password)
    create_tunnel_C()
    error = ping_test()
    if error==1:
        return 2
    delete_tunnel_C()
    return 0

def del_tunnel():
    user_info = read_userinfo()
    if user_info[0]==0:
        return -1
    tunnel_info = iftunnel()
    if tunnel_info==0:
        return  0
    if tunnel_info == 1:
        error = delete_tunnel_A()
        return error
    if tunnel_info == 2:
        error = delete_tunnel_C()
        return error*2
    return -1
    
