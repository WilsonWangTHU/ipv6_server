from function import *

tunnel_prefix='sudo /usr/bin/curl -d type=%r -d username=%r -d password=%r '
tunnel_option1=' -d tid=%s '
tunnel_option2=' -d ipv4_server=%r '
tunnel_postfix=' 121.194.167.60/raspberry/tunnel/'

def tunnel_communicate_user_auth(username,password):
    string = tunnel_prefix+tunnel_postfix
    cmd = string % (0,username,password)
    #print cmd
    result = send_message(cmd)
    return result

def tunnel_communicate_create_tunnel_A(username,password):
    string = tunnel_prefix+tunnel_postfix
    cmd = string % (1,username,password)
    #print cmd
    result = send_message(cmd)
    return result

def tunnel_communicate_delete_tunnel_A(username,password,tid):
    string = tunnel_prefix+tunnel_option1+tunnel_postfix
    cmd = string % (2,username,password,tid)
    #print cmd
    result = send_message(cmd)
    return result

def tunnel_communicate_create_tunnel_C(username,password,ipv4_server):
    string = tunnel_prefix+tunnel_option2+tunnel_postfix
    cmd = string % (3,username,password,ipv4_server)
    #print cmd
    result = send_message(cmd)
    return result

def tunnel_communicate_delete_tunnel_C(username,password,ipv4_server):
    string = tunnel_prefix+tunnel_option2+tunnel_postfix
    cmd = string % (4,username,password,ipv4_server)
    print cmd
    result = send_message(cmd)
    return result

    
