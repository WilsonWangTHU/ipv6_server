from function import *
from user_tunnel_info import *

dns_file='/etc/resolv.conf'

def return_ipv6_addr():
    user_info=read_userinfo()
    ipv6_addr_gate = user_info[4].split('/')[0]+'1'
    return (user_info[4],ipv6_addr_gate)

def return_ipv6_ivi_addr():
    user_info=read_userinfo()
    ivi_t = user_info[5].split('/')[0]
    ipv6_ivi_addr_gate=ivi_t[:-1]+'4000::'
    return (user_info[5],ipv6_ivi_addr_gate)

def return_dns_server():
    t=read_file(dns_file)
    dns_info = t.split('\n')
    dns_addr = []
    for i in dns_info:
        if len(i)>0:
            t_addr = i.split(' ')[1]
            dns_addr.append(t_addr)
    return dns_addr

def return_ipv4_global_addr():
    user_info=read_userinfo()
    return user_info[6]
