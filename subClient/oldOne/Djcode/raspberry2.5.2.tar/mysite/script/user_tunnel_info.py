from function import *
from communicate_with_server import *

userinfo_file='/etc/tunnel_config/user_info'
tunnelinfo_file='/etc/tunnel_config/tunnel_info'
login_firstconf_file='/etc/tunnel_config/first_conf'

def write_userinfo(username,password):
    t0 = tunnel_communicate_user_auth(username,password)
    userinfo_from_server = t0.split(',')
    if userinfo_from_server[0]!='1':
        return 0
    string = '1,'+username+','+password+','+userinfo_from_server[1]+','+userinfo_from_server[2]+','+userinfo_from_server[3]+','+userinfo_from_server[4]+','
    write_file(userinfo_file,string)
    return 1

def reset_userinfo():
    string = '0,0,0,0,0,0,0,'
    write_file(userinfo_file,string)

def read_userinfo():
    try:
        t = read_file(userinfo_file)
    except IOError:
        return (0,'0','0','0','0','0','0')
    u = t.split(',')
    flag = int(u[0])
    return (flag,u[1],u[2],u[3],u[4],u[5],u[6])

def read_tunnelinfo():
    try:
        t = read_file(tunnelinfo_file)
    except IOError:
        return (0,'0','0','0','0','0')
    u = t.split(',')
    flag = int(u[0])
    return (flag,u[1],u[2],u[3],u[4],u[5])

def reset_tunnelinfo():
    string = '0,0,0,0,0,0,'
    write_file(tunnelinfo_file,string)

def write_tunnel_info_A(username,password):
    t = tunnel_communicate_create_tunnel_A(username,password)
    tunnelinfo_from_server = t.split(',')
    if tunnelinfo_from_server[0]!='1':
        return 0
    write_file(tunnelinfo_file,t)

def write_tunnel_info_C(username,password):
    ipv4_server = '121.194.167.60'
    t = tunnel_communicate_create_tunnel_C(username,password,ipv4_server)
    string = '2,'+ipv4_server+',0,0,0,0,'
    write_file(tunnelinfo_file,string)

def set_first_conf(flag):
    write_file(login_firstconf_file,flag)

def read_first_conf():
    try:
        t = read_file(login_firstconf_file)
    except IOError:
        return 0
    flag = int(t[0])
    return flag

