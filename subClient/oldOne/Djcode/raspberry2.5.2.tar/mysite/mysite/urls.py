from django.conf.urls import patterns, include, url
from django.contrib import admin
import settings
from mysite import views

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'mysite.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'login/$', views.login),
    url(r'login/submit/$',views.login_submit),
    #url(r'^$',views.test),
    url(r'^$',views.info),
    url(r'tunnel type/choose/$',views.choose_tunnel),
    url(r'tunnel type/delete/$',views.delete_tunnel),
    url(r'logout/$',views.logout ),
    url(r'tunnel check/$',views.ifconfig),
)
