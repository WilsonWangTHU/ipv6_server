import subprocess
import hashlib

def md5(t_str):
    m = hashlib.md5()
    m.update(t_str)
    return m.hexdigest()

def write_file(filename,string):
    output=open(filename,'w')
    output.write(string)
    output.close()

def read_file(filename):
    innput=open(filename,'r')
    all_text = innput.read()
    innput.close()
    return all_text

def send_message(cmd):
    p = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (t_out,err)=p.communicate()
    out = t_out.split('\n')
    t = out[0]
    return t_out 


