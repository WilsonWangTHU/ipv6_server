from function import *
from communicate_with_server import *
from user_tunnel_info import *
import os



def config_tunnel_A(ipv4_s,ipv4_c,ipv6_s,ipv6_c):
    cmd_list=[]
    cmd_list.append("sudo ip tunnel add sitCernet64 mode sit ttl 128 remote %s local %s"%(ipv4_s,ipv4_c))
    cmd_list.append("sudo ip link set sitCernet64 up")
    cmd_list.append("sudo ip -6 route add ::/0 dev sitCernet64 metric 1")
    cmd_list.append("sudo ip -6 addr add %s dev sitCernet64"%ipv6_c)
    i=0
    while i<4:
        #send_message(cmd_list[i])
        os.system(cmd_list[i])
        i+=1

def delete_tunnel_A():
    user_info = read_userinfo()
    if user_info[0]==0:
        return 0
    username = user_info[1]
    password = user_info[2]
    tunnel_info = read_tunnelinfo()
    if tunnel_info!=1:
        return 0
    tunnel_communicate_delete_tunnel_A(username,password)
    cmd = "sudo ip tunnel del sitCernet64"
    os.system(cmd)
    reset_tunnelinfo()
    return 1   

def create_tunnel_A():
    user_info = read_userinfo()
    if user_info[0]==0:
        return 0 
    tunnel_A_info = read_tunnelinfo()
    if tunnel_A_info!=1:
        return 0
    ipv4_s = user_info[3]
    ipv4_c = user_info[4]
    ipv6_s = user_info[8]
    ipv6_c = user_info[9]
    config_tunnel_A(ipv4_s,ipv4_c,ipv6_s,ipv6_c)
    
    
def create_tunnel_C():
    user_info = read_userinfo()
    if user_info[0]==0:
        return 0
    tunnel_C_info = read_tunnelinfo()
    if tunnel_C_info!=2:
        return 0
    cmd = "sudo service openvpn start"
    os.system(cmd)
    return 1

def delete_tunnel_C():
    user_info = read_userinfo()
    if user_info[0]==0:
        return 0
    username = user_info[1]
    password = user_info[2]
    tunnel_info = read_tunnelinfo()
    if tunnel_info!=2:
        return 0
    tunnel_communicate_delete_tunnel_C(username,password)
    cmd = "sudo service openvpn stop"
    os.system(cmd)
    reset_tunnelinfo()
    return 1   
    
    
