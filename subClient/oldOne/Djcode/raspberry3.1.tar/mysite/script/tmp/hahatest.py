#!/usr/bin/python
def ip():
    import os
    import sys
    from communicate_with_server import*
    from tunnel_local_manage import*
    from user_tunnel_info import*
