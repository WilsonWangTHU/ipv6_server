#!/usr/bin/python
import os
from sys import path
path.append(r"/project/Djcode/mysite/script")
from function import *
from user_tunnel_info import *
from tunnel_local_manage import *
from read_tunnel_info import *
import ping_test

def iflogin():
    result = read_config('State','if_login')
    error = result
    return error

def iftunnel():
    result = read_config('State','tunnel_type')
    return result

def return_username():
    result = read_config('UserInfo','username')
    return result

def return_tunnel_info():
    ipv6_addr_info = return_ipv6_addr()
    ivi_addr_info = return_ipv6_ivi_addr()
    dns_info = return_dns_server()
    ipv4_global_addr = return_ipv4_global_addr()
    server_addr = return_server_address()
    return (ipv6_addr_info,ivi_addr_info,dns_info,ipv4_global_addr,server_addr)

def quit_login(t):
    delete_tunnel_A()
    delete_tunnel_C()
    if t==1:
        tunnel_communicate_name('relbd')
    reset_userinfo()
    os.system("sudo /project/Djcode/mysite/script/logout_change_file")
        
def iftong():
    flag = read_config('State','if_first_login')
    if flag==1:
        return 1
    else:
        return 0

def user_auth(username,password):
    pd = md5(str(password))
    change_auth(str(username),pd)
    error = tunnel_communicate_name('auth')
    return int(error)

def first_config_tunnel():
    os.system("sudo /project/Djcode/mysite/script/network_config.shell &")

def userlogin(resquest):
    t_username = resquest.POST.get('username','')
    t_password = resquest.POST.get('password','')
    pd = md5(t_password)
    result = write_userinfo(str(t_username),pd)
    if result==0:
        return 0
    #t_flag = tunnel_communicate_if_exsit(str(t_username),pd)
    #flag = int(t_flag)
    #if flag!=1:
    #    reset_userinfo()
    return 1

def tunnel_con1():
    login_flag = read_config('State','if_login')
    if login_flag==0:
        return 0
    tunnel_type = read_config('State','tunnel_type')
    if tunnel_type!=0:
        return 0 

    error = write_tunnel_A()
    if error == -1:
        return -1
    create_tunnel_A()
    error = ping_test.ping_test()
    if error==1:
        return 1
    delete_tunnel_A()
    return 0

def tunnel_con2():
    login_flag = read_config('State','if_login')
    if login_flag==0:
        return 0
    tunnel_type = read_config('State','tunnel_type')
    if tunnel_type!=0:
        return 0 
    error = write_tunnel_C()
    if error == -1:
        return -1
    create_tunnel_C()
    error = ping_test.ping_test()
    if error==1:
        return 2
    delete_tunnel_C()
    return 0

def tunnel_con3():
    login_flag = read_config('State','if_login')
    if login_flag==0:
        return 0
    tunnel_type = read_config('State','tunnel_type')
    if tunnel_type!=0:
        return 0 
    error = write_tunnel_A()
    if error == -1:
        return -1
    create_tunnel_A()
    error = ping_test.ping_test()
    if error==1:
        return 1
    delete_tunnel_A()
    error = write_tunnel_C()
    if error == -1:
        return -1
    create_tunnel_C()
    error = ping_test.ping_test()
    if error==1:
        return 2
    delete_tunnel_C()
    return 0

def del_tunnel():
    login_flag = read_config('State','if_login')
    if login_flag==0:
        return -1
    tunnel_type = read_config('State','tunnel_type')
    if tunnel_type==0:
        return  0
    if tunnel_type == 1:
        error = delete_tunnel_A()
        return error
    if tunnel_type == 2:
        error = delete_tunnel_C()
        return error*2
    return -1


def check_mac():
    mac = get_mac()
    error = write_userinfo(mac)
    return error    


    
