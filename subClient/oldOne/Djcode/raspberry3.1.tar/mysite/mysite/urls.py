from django.conf.urls import patterns, include, url
from django.contrib import admin
import settings
from mysite import views

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'mysite.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),

    url(r'mac_error/$', views.mac_error),

    url(r'guide_page/0/$',views.guide_zero),
    url(r'guide_page/1/$',views.guide_one),
    url(r'guide_page/2/$',views.guide_two),
    
    url(r'first_config/$',views.first_config),

    url(r'userauth/$',views.userauth),
    url(r'userauth/result/$',views.guide_two),
    
    url(r'logout1/$',views.logout1),
    url(r'logout2/$',views.logout2),
    

    #url(r'^$',views.test),
    url(r'^$',views.info),
    url(r'tunnel type/choose/$',views.choose_tunnel),
    url(r'tunnel type/delete/$',views.delete_tunnel),
    #url(r'logout/$',views.logout ),
    url(r'tunnel check/$',views.ifconfig),
)
