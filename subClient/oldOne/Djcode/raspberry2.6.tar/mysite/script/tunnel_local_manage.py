from function import *
from communicate_with_server import *
from user_tunnel_info import *


def config_tunnel_A(ipv4_s,ipv4_c,ipv6_s,ipv6_c):
    cmd_list=[]
    cmd_list.append("sudo ip tunnel add sitCernet64 mode sit ttl 128 remote "+ipv4_s+" local "+ipv4_c)
    cmd_list.append("sudo ip link set sitCernet64 up")
    cmd_list.append("sudo ip -6 route add ::/0 dev sitCernet64 metric 1")
    cmd_list.append("sudo ip -6 addr add "+ipv6_c+" dev sitCernet64")
    i=0
    while i<4:
        send_message(cmd_list[i])
        i+=1

def delete_tunnel_A():
    user_info = read_userinfo()
    if user_info[0]==0:
        return 0
    username = user_info[1]
    password = user_info[2]
    tunnel_info = read_tunnelinfo()
    if tunnel_info[0]!=1:
        return 0
    tid = tunnel_info[5]
    tunnel_communicate_delete_tunnel_A(username,password,tid)
    cmd = "sudo ip tunnel del sitCernet64"
    send_message(cmd)
    reset_tunnelinfo()
    return 1   

def create_tunnel_A():
    user_info = read_userinfo()
    if user_info[0]==0:
        return 0 
    t = read_tunnelinfo()
    tunnel_A_info = t
    if tunnel_A_info[0]!=1:
        return 0
    ipv4_s = tunnel_A_info[1]
    ipv4_c = tunnel_A_info[2]
    ipv6_s = tunnel_A_info[3]
    ipv6_c = tunnel_A_info[4]
    config_tunnel_A(ipv4_s,ipv4_c,ipv6_s,ipv6_c)
    
def create_tunnel_C():
    user_info = read_userinfo()
    if user_info[0]==0:
        return 0
    t = read_tunnelinfo()
    tunnel_C_info = t
    if tunnel_C_info[0]!=2:
        return 0
    cmd = "sudo service openvpn start"
    send_message(cmd)
    return 1

def delete_tunnel_C():
    user_info = read_userinfo()
    if user_info[0]==0:
        return 0
    username = user_info[1]
    password = user_info[2]
    tunnel_info = read_tunnelinfo()
    if tunnel_info[0]!=2:
        return 0
    ipv4_server = tunnel_info[1]
    tunnel_communicate_delete_tunnel_C(username,password,ipv4_server)
    cmd = "sudo service openvpn stop"
    send_message(cmd)
    reset_tunnelinfo()
    return 1   
    
    
