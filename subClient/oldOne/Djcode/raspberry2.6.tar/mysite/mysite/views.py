from django.shortcuts import render,render_to_response
from django.template.loader import get_template
from django.template import Context
from django.http import HttpResponse, HttpResponseRedirect
from mysite.tunnel_function import *

def test(request):
    return render_to_response('test.html')

def login(request):
    
    login_flag=iflogin()
    if login_flag==1:
        return render_to_response('jump.html',{'jump_kind':1,'error':2,'next':'/'})
    return render_to_response('login.html')

def login_submit(request):
    login_flag=iflogin()
    if login_flag==1:
        return render_to_response('jump.html',{'jump_kind':1,'error':2,'next':'/'})
        
    error = userlogin(request)
    next_page='/login'
    html_page='jump.html'
    if error==1:
        first_config()
        html_page='first_login.html'
    return render_to_response(html_page,{'jump_kind':1,'error':error,'next':next_page})

def info(request):
    error = iflogin()
    if error==0:
        return render_to_response('jump.html',{'jump_kind':0,'next':'/login'})
    if error!=1:
        return render_to_response('jump.html',{'jump_kind':-1,'next':'/login'})
    error=iftunnel()
    info_tuple=return_tunnel_info()
    dns_len = len(info_tuple[2])
    return render_to_response('info.html',{'tunnel_type':error,'v6_net':info_tuple[0][0],'v6_gate':info_tuple[0][1],'ivi_net':info_tuple[1][0],'ivi_gate':info_tuple[1][1],'dns_list':info_tuple[2],'v4_global':info_tuple[3],'server_addr':info_tuple[4][0],'server_ivi_addr':info_tuple[4][1]})

def ifconfig(response):
    response=HttpResponse()
    response['Contene-Type']="text/javascript"
    error = iftong()
    response.write(error)
    return response

def logout(request):
    error = quit_login()
    return render_to_response('jump.html',{'jump_kind':4,'next':'/login','error':error})

def choose_tunnel(request):
    error = iflogin()
    if error==0:
        return render_to_response('jump.html',{'jump_kind':0,'next':'/login'})  
    error = iftunnel()
    t = request.POST.get('type','')
    tunnel_type = int(t)
    if error != 0:
        return render_to_response('jump.html',{'jump_kind':2,'next':'/','error':3})
    error=-1
    if tunnel_type==1:
        error = tunnel_con1()
    if tunnel_type == 2:
        error = tunnel_con2()
    if tunnel_type == 3:
        error = tunnel_con3()
    return render_to_response('jump.html',{'jump_kind':2,'next':'/','error':error})

def delete_tunnel(request):
    error = del_tunnel()
    return render_to_response('jump.html',{'jump_kind':3,'next':'/','error':error})
    

